DROP TABLE IF EXISTS `phpcms_okrobot_userinfo`;
CREATE TABLE `phpcms_okrobot_userinfo` (
    `id` bigint(11) NOT NULL AUTO_INCREMENT,
    `asset` varchar(256) comment '账户资产',
    `borrow` varchar(256) comment '账户借款信息',
    `free` varchar(256) comment '账户余额',
    `freezed` varchar(256) comment '账户余额冻结',
    `union_fund` varchar(256) comment '账户理财信息',
    PRIMARY KEY (`id`)
) TYPE=MyISAM;
