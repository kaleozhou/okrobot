INSERT INTO `phpcms_module` (
    `module`, `name`, `url`, `iscore`, `version`, `description`, `setting`, `listorder`, `disabled`, `installdate`, `updatedate`)
VALUES ('ziyuan', '资源', '', '0', '1.0', '', '', '0', '0', '2010-09-06', '2010-09-06');
