<?php
/** =============================================================================
 * @name model.php
 * @date date 2016年11月28日 星期一 14时57分17秒
 * @author kaleo <kaleo1990@hotmail.com>
 * @package 
 * =============================================================================
 */
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
return array('ziyuan');
