<?php
/** =============================================================================
 * @name config.inc.php
 * @date date 2016年11月28日 星期一 14时29分17秒
 * @author kaleo <kaleo1990@hotmail.com>
 * @package 
 * =============================================================================
 */
defined('IN_PHPCMS') or exit('Access Denied');
defined('INSTALL') or exit('Access Denied');
$module = 'ziyuan'; //模块的标识符，唯一性，不可重名,应该和目录同名
$modulename = '资源'; 
$introduce = '收集资源';
$author = 'kaleo';
$authorsite = 'http://www.qmzhentan.com';
$authoremail = 'kaleo1990@hotmail.com';
